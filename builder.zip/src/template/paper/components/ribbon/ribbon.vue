<template>
    <div>
        <slot></slot>
    </div>
</template>


<script>
    import "./ribbon.scss"
    export default {}
</script>
