export const getTitle = (state) => {
    return state.title
}