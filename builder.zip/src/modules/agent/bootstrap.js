import Vue from 'vue'

window.Vue = Vue;
Vue.config.productionTip = false;
