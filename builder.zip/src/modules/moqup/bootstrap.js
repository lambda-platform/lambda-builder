import Vue from 'vue'
import _ from 'lodash'

window._ = _;
window.Vue = Vue;
Vue.config.productionTip = false;
Vue.config.silent = true;
