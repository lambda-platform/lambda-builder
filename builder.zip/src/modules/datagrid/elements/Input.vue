<template>
    <Input type="text"/>
</template>

<script>
import Vue from "vue";
export default Vue.extend();
</script>
