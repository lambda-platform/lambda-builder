export default {

    elementTypes(state){
        return state.elementTypes;
    },
    title(state){
        return state.title;
    },
    other(state){
        return state.other;
    },
    table(state){
        return state.table;
    },
    elementType(state){
        return state.elementType;
    },
    data(state){
        return state.data;
    },
    areaLineColumnFields(state){
        return state.areaLineColumnFields;
    },
    pieColumnFields(state){
        return state.pieColumnFields
    },
    countBox(state){
        return state.countBox
    },

    tableFields(state){
        return state.tableFields
    },

    radarFields(state){
        return state.radarFields
    },

    fields(state){
        return state.fields
    },


}
