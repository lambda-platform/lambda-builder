<template>

</template>

<script>
export default {
name: "Report"
}
</script>

<style scoped>

</style>
