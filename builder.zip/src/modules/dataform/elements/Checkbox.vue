<template>
    <FormItem :prop=rule>
        <Checkbox
            v-model="model.form[model.component]"
            :disabled="meta && meta.disabled ? meta.disabled : false"
            :true-value="1"
            :false-value="0">{{ label }}
        </Checkbox>
    </FormItem>
</template>

<script>
export default {
    props: ["model", "label", "rule", "meta"],
};
</script>
