<template>
    <h3>
        404 not found
    </h3>
</template>

<script>
    export default {}
</script>
