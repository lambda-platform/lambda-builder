<template>
    <iframe src="/lambda/puzzle/builder" frameborder="0"></iframe>
</template>

<script>
export default {
    name: "index"
}
</script>

<style scoped>
    iframe{
        width: 100%;
        height: 100vh;
    }
</style>
