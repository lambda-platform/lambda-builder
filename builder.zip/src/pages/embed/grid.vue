<template>
    <datagrid :schemaID="$route.params.id" :paginate="50"></datagrid>
</template>

<script>
    export default {
    };
</script>
